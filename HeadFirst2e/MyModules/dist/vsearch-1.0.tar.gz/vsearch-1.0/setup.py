"""
:str and ->set are anotation which documented thet the input is str type and return is set type
"""
from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The match character module',
    url='http:\\google.com',
    author='nehal',
    author_email='kumarnehal31@gmail.com',
    py_module=['vsearch'],
    )
